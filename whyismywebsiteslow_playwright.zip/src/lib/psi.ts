import type { Device } from "./types";
import { computePseudoLighthouseScores, runPlaywrightScan } from "./playwrightScan";

export type PsiResult = {
  source: "live" | "mock";
  message?: string;
  lighthouse: {
    performance: number;
    accessibility: number;
    bestPractices: number;
    seo: number;
  };
  cwv: {
    lcp_ms?: number;
    inp_ms?: number;
    cls?: number;
    fcp_ms?: number;
    ttfb_ms?: number;
    status: "pass" | "fail" | "unknown";
  };
  audits: {
    renderBlocking?: boolean;
    unusedJsBytes?: number;
    unusedCssBytes?: number;
    totalByteWeight?: number;
    imageOptimization?: boolean;
    cachePolicy?: boolean;
  };
};

function toScore(value: number | undefined) {
  if (typeof value !== "number") return 0;
  return Math.round(value * 100) / 100;
}

export async function fetchPsi(url: string, device: Device): Promise<PsiResult> {
  try {
    const scan = await runPlaywrightScan(url, device);
    const lighthouse = computePseudoLighthouseScores(scan.timings);

    const lcp = scan.timings.lcp_ms;
    const inp = scan.timings.inp_ms;
    const cls = scan.timings.cls;

    const status =
      (typeof lcp === "number" ? lcp <= 2500 : true) &&
      (typeof inp === "number" ? inp <= 200 : true) &&
      (typeof cls === "number" ? cls <= 0.1 : true)
        ? "pass"
        : "fail";

    return {
      source: "live",
      message: "Playwright live scan (no API key)",
      lighthouse: {
        performance: toScore(lighthouse.performance),
        accessibility: toScore(lighthouse.accessibility),
        bestPractices: toScore(lighthouse.bestPractices),
        seo: toScore(lighthouse.seo),
      },
      cwv: {
        lcp_ms: scan.timings.lcp_ms,
        inp_ms: scan.timings.inp_ms,
        cls: scan.timings.cls,
        fcp_ms: scan.timings.fcp_ms,
        ttfb_ms: scan.timings.ttfb_ms,
        status,
      },
      audits: {
        renderBlocking: scan.hints.renderBlocking,
        totalByteWeight: scan.bytes.total,
        imageOptimization: scan.hints.imageOptimizationLikelyNeeded,
        cachePolicy: scan.hints.cachePolicyLooksBad,
        unusedJsBytes: undefined,
        unusedCssBytes: undefined,
      },
    };
  } catch (err: any) {
    return {
      ...mockPsi(),
      message: `Playwright scan failed; using mock data (${err?.message ?? "unknown"})`,
    };
  }
}

function mockPsi(): PsiResult {
  return {
    source: "mock",
    message: "Mock scan data",
    lighthouse: {
      performance: 0.78,
      accessibility: 0.92,
      bestPractices: 0.88,
      seo: 0.9,
    },
    cwv: {
      lcp_ms: 3200,
      inp_ms: 240,
      cls: 0.12,
      fcp_ms: 2100,
      ttfb_ms: 700,
      status: "fail",
    },
    audits: {
      renderBlocking: true,
      unusedJsBytes: 220000,
      unusedCssBytes: 80000,
      totalByteWeight: 3400000,
      imageOptimization: true,
      cachePolicy: true,
    },
  };
}
