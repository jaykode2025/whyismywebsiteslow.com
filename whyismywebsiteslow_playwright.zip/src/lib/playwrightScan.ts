import chromium from "@sparticuz/chromium";
import { chromium as pwChromium, type Browser, type Page } from "playwright-core";
import type { Device } from "./types";

export type PlaywrightScanResult = {
  timings: {
    ttfb_ms?: number;
    fcp_ms?: number;
    lcp_ms?: number;
    cls?: number;
    inp_ms?: number;
  };
  bytes: {
    total: number;
    html: number;
    js: number;
    css: number;
    image: number;
    font: number;
    other: number;
  };
  requests: {
    total: number;
    thirdParty: number;
  };
  hints: {
    renderBlocking: boolean;
    cachePolicyLooksBad: boolean;
    imageOptimizationLikelyNeeded: boolean;
  };
};

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function scoreFromThreshold(value: number | undefined, good: number, ni: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return 0.5;
  const s = 1 - (value - good) / (ni - good);
  return clamp(s, 0, 1);
}

export function computePseudoLighthouseScores(m: PlaywrightScanResult["timings"]) {
  const perf =
    Math.round(
      100 *
        (0.45 * scoreFromThreshold(m.lcp_ms, 2500, 4000) +
          0.25 * scoreFromThreshold(m.inp_ms, 200, 500) +
          0.2 * scoreFromThreshold(m.cls, 0.1, 0.25) +
          0.1 * scoreFromThreshold(m.ttfb_ms, 800, 1800))
    ) / 100;

  return {
    performance: clamp(perf, 0, 1),
    accessibility: 0.75,
    bestPractices: 0.75,
    seo: 0.75,
  };
}

function isThirdParty(requestUrl: string, primaryHost: string) {
  try {
    const u = new URL(requestUrl);
    return u.hostname !== primaryHost && !u.hostname.endsWith(`.${primaryHost}`);
  } catch {
    return false;
  }
}

function classifyContentType(contentType: string | null | undefined, url: string) {
  const ct = (contentType ?? "").toLowerCase();
  if (ct.includes("text/html")) return "html";
  if (ct.includes("javascript") || ct.includes("ecmascript")) return "js";
  if (ct.includes("text/css")) return "css";
  if (ct.startsWith("image/")) return "image";
  if (ct.includes("font") || ct.includes("woff") || ct.includes("ttf") || ct.includes("otf")) return "font";
  const p = url.split("?")[0].toLowerCase();
  if (p.endsWith(".js")) return "js";
  if (p.endsWith(".css")) return "css";
  if (/(\.png|\.jpg|\.jpeg|\.gif|\.webp|\.avif|\.svg)$/.test(p)) return "image";
  if (/(\.woff2|\.woff|\.ttf|\.otf)$/.test(p)) return "font";
  return "other";
}

async function newBrowser(): Promise<Browser> {
  const executablePath =
    process.env.CHROME_EXECUTABLE_PATH ||
    (await chromium.executablePath().catch(() => undefined));

  return pwChromium.launch({
    args: chromium.args,
    executablePath,
    headless: chromium.headless,
  });
}

async function setupPage(page: Page, device: Device) {
  if (device === "mobile") {
    await page.setViewportSize({ width: 412, height: 915 });
    await page.setUserAgent(
      "Mozilla/5.0 (Linux; Android 12; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    );
  } else {
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.setUserAgent(
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );
  }

  page.setDefaultNavigationTimeout(45_000);
  page.setDefaultTimeout(45_000);
}

export async function runPlaywrightScan(url: string, device: Device): Promise<PlaywrightScanResult> {
  const primaryHost = new URL(url).hostname;

  const totals = {
    total: 0,
    html: 0,
    js: 0,
    css: 0,
    image: 0,
    font: 0,
    other: 0,
  };

  let requestCount = 0;
  let thirdPartyCount = 0;
  let cacheLooksBad = false;

  const browser = await newBrowser();
  const page = await browser.newPage();
  await setupPage(page, device);

  page.on("response", async (res) => {
    try {
      const resUrl = res.url();
      requestCount += 1;
      if (isThirdParty(resUrl, primaryHost)) thirdPartyCount += 1;

      const cc = res.headers()["cache-control"];
      if (cc && /max-age=(\d+)/i.test(cc)) {
        const m = cc.match(/max-age=(\d+)/i);
        const maxAge = m ? Number(m[1]) : 0;
        const type = classifyContentType(res.headers()["content-type"], resUrl);
        if (["js", "css", "image", "font"].includes(type) && maxAge < 3600) {
          cacheLooksBad = true;
        }
      } else {
        const type = classifyContentType(res.headers()["content-type"], resUrl);
        if (["js", "css", "image", "font"].includes(type)) {
          cacheLooksBad = true;
        }
      }

      const ct = res.headers()["content-type"];
      const type = classifyContentType(ct, resUrl);
      const lenHeader = res.headers()["content-length"];
      let size = lenHeader ? Number(lenHeader) : NaN;
      if (!Number.isFinite(size)) {
        size = 0;
      }
      totals.total += size;
      totals[type as keyof typeof totals] += size;
    } catch {
      // ignore
    }
  });

  await page.goto(url, { waitUntil: "networkidle" });

  const vitals = await page.evaluate(async () => {
    const out: any = { cls: 0 };

    try {
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries() as any[]) {
          if (!entry.hadRecentInput) out.cls += entry.value;
        }
      }).observe({ type: "layout-shift", buffered: true } as any);
    } catch {}

    try {
      new PerformanceObserver((list) => {
        const entries = list.getEntries() as any[];
        const last = entries[entries.length - 1];
        if (last) out.lcp = last.startTime;
      }).observe({ type: "largest-contentful-paint", buffered: true } as any);
    } catch {}

    try {
      let max = 0;
      new PerformanceObserver((list) => {
        for (const e of list.getEntries() as any[]) {
          const dur = e.duration ?? 0;
          if (dur > max) max = dur;
        }
        out.inp = max;
      }).observe({ type: "event", buffered: true, durationThreshold: 16 } as any);
    } catch {}

    try {
      const nav = performance.getEntriesByType("navigation")[0] as any;
      if (nav) out.ttfb = nav.responseStart;
    } catch {}
    try {
      const fcp = performance.getEntriesByName("first-contentful-paint")[0] as any;
      if (fcp) out.fcp = fcp.startTime;
    } catch {}

    await new Promise((r) => setTimeout(r, 1500));
    return out;
  });

  const renderBlocking = await page.evaluate(() => {
    const head = document.head;
    if (!head) return false;
    const sheets = Array.from(head.querySelectorAll('link[rel="stylesheet"][href]'));
    const blockingScripts = Array.from(head.querySelectorAll('script[src]:not([async]):not([defer])'));
    return sheets.length > 0 || blockingScripts.length > 0;
  });

  const imageOptimizationLikelyNeeded = await page.evaluate(() => {
    const imgs = Array.from(document.images || []);
    let big = 0;
    let legacy = 0;
    for (const img of imgs) {
      const src = (img.currentSrc || img.src || "").toLowerCase();
      if (img.naturalWidth * img.naturalHeight > 1920 * 1080) big++;
      if (src.endsWith(".png") || src.endsWith(".jpg") || src.endsWith(".jpeg")) legacy++;
    }
    return big > 0 || legacy > 0;
  });

  await page.close().catch(() => undefined);
  await browser.close().catch(() => undefined);

  return {
    timings: {
      ttfb_ms: typeof vitals.ttfb === "number" ? vitals.ttfb : undefined,
      fcp_ms: typeof vitals.fcp === "number" ? vitals.fcp : undefined,
      lcp_ms: typeof vitals.lcp === "number" ? vitals.lcp : undefined,
      cls: typeof vitals.cls === "number" ? vitals.cls : undefined,
      inp_ms: typeof vitals.inp === "number" ? vitals.inp : undefined,
    },
    bytes: totals,
    requests: {
      total: requestCount,
      thirdParty: thirdPartyCount,
    },
    hints: {
      renderBlocking,
      cachePolicyLooksBad: cacheLooksBad,
      imageOptimizationLikelyNeeded,
    },
  };
}
